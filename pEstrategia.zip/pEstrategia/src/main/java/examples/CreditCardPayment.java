package examples;

import lombok.AllArgsConstructor;

    @AllArgsConstructor
    public class CreditCardPayment implements PaymentStrategy {
        private String cardNumber;

        @Override
        public void pay(double amount) {
            System.out.println("Pagando " + amount + " con tarjeta de crédito: " + cardNumber);
        }

    }