package examples;

    public static void main(String[] args) {
        ShoppingCart cart = new ShoppingCart();
        cart.addItem(20);
        cart.addItem(50);

        cart.setPaymentStrategy(new CreditCardPayment("1234-5678-9012-3456"));
        cart.checkout();
    }

    public void main() {
    }