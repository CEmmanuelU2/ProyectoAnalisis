package examples;
import lombok.AllArgsConstructor;

@AllArgsConstructor

public class PayPalPayment implements PaymentStrategy {
    private String email;

    @Override
    public void pay(double amount) {
        System.out.println("Pagando " + amount + " a través de PayPal usando la cuenta: " + email);
    }
}